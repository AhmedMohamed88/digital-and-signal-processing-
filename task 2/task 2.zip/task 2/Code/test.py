j="1"
j="00" +j
print(j)